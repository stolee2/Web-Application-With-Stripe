-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2024 at 02:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project-12`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `prodid` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'unpaid',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `prodid`, `userid`, `price`, `status`, `date`) VALUES
(161, '22', '7', '120', 'paid', '2024-06-09 09:21:29'),
(162, '23', '7', '199', 'paid', '2024-06-09 09:22:36'),
(164, '27', '7', '17', 'paid', '2024-06-09 09:27:36'),
(165, '27', '7', '17', 'paid', '2024-06-09 09:28:18'),
(167, '26', '7', '12', 'paid', '2024-06-09 09:32:56'),
(179, '20', '7', '230', 'paid', '2024-06-09 10:11:14'),
(180, '22', '7', '120', 'paid', '2024-06-09 10:11:18'),
(181, '20', '7', '230', 'paid', '2024-06-09 10:32:49'),
(182, '21', '7', '180', 'paid', '2024-06-09 10:42:02'),
(183, '24', '7', '99', 'paid', '2024-06-09 10:45:49'),
(190, '21', '6', '180', 'paid', '2024-06-10 05:28:46'),
(191, '21', '6', '180', 'paid', '2024-06-10 05:29:00'),
(194, '21', '6', '180', 'paid', '2024-06-10 06:03:54'),
(195, '21', '6', '180', 'paid', '2024-06-10 06:04:14'),
(200, '21', '6', '180', 'paid', '2024-06-10 06:13:56'),
(201, '20', '6', '230', 'paid', '2024-06-10 06:13:59'),
(202, '22', '6', '120', 'paid', '2024-06-10 06:24:05'),
(204, '25', '6', '15', 'paid', '2024-06-10 06:35:18'),
(205, '21', '6', '180', 'paid', '2024-06-10 06:35:21'),
(206, '22', '6', '120', 'paid', '2024-06-10 06:42:15'),
(208, '25', '6', '15', 'paid', '2024-06-10 06:47:17'),
(209, '24', '6', '99', 'paid', '2024-06-10 06:47:22'),
(213, '24', '6', '99', 'paid', '2024-06-10 08:38:49'),
(225, '21', '8', '180', 'paid', '2024-06-10 15:27:59'),
(235, '25', '8', '15', 'paid', '2024-06-13 07:41:02'),
(236, '24', '8', '99', 'paid', '2024-06-13 07:41:07'),
(237, '21', '8', '180', 'paid', '2024-06-13 08:03:25'),
(238, '21', '8', '180', 'paid', '2024-06-13 10:08:26'),
(239, '24', '8', '99', 'paid', '2024-06-13 10:10:44'),
(240, '25', '8', '15', 'paid', '2024-06-13 10:10:53'),
(243, '25', '4', '15', 'unpaid', '2024-06-13 12:45:15'),
(244, '24', '4', '99', 'unpaid', '2024-06-13 12:45:31');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `admin` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `admin`, `title`, `description`, `category`, `price`, `img`, `date`) VALUES
(20, '5', 'Treadmill', 'Machine for running', 'equipments', '230', '880f93005b2c1c104f97177563880907.jpg', '2024-05-31 23:48:44'),
(21, '5', 'spinn bake', '', 'equipments', '180', 'c7556a42112ec2347cdbec8f0772ed38.jpg', '2024-05-31 23:49:42'),
(22, '5', 'Biceps Curl', '', 'equipments', '120', '7cd0585b89776ded8636bd1a6ccb5059.jpg', '2024-05-31 23:51:49'),
(23, '5', 'Leg Press', '', 'equipments', '199', 'a97ee145b6c2711e3fad4a1bb8f1eda7.jpg', '2024-05-31 23:52:45'),
(24, '5', 'Leg Extension', '', 'equipments', '99', 'af6aa5d7a6e73ac10677de79c5446bba.jpg', '2024-05-31 23:54:06'),
(25, '5', 'Hodie  Size L', '', 'cloths', '15', '8f85ac5e7cf722f3481c08bc6a6233b3.jpg', '2024-05-31 23:58:35'),
(26, '5', 'T-shirt Size L', '', 'cloths', '12', 'e323a823eeeb4b2d4908b719ba734690.jpg', '2024-06-01 00:00:00'),
(27, '5', 'Hodie  Size M', '', 'cloths', '17', '864c6dd533e9360c6d623513cb6cdf73.jpg', '2024-06-01 00:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `date`) VALUES
(4, 'a', '123@gmail.com', '123', '2024-04-13 17:43:56'),
(5, 'Admin', 'admin@gmail.com', 'admin', '2024-05-20 17:43:56'),
(6, 'ristov', 'stole@gmail.com', '123', '2024-05-31 22:03:10'),
(8, 'Stole', 'stole.ristov1212@gmail.com', '123', '2024-06-10 15:22:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
