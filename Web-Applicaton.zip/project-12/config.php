<?php
$host = 'localhost';
$user ='root';
$pass = '';
$db = 'project-12';
$con = mysqli_connect($host,$user,$pass,$db);
if ($con==true) {
	# code...
}else{
	die('connection_aborted');
}
function rdi($val){
	echo "<script>window.location.href='$val'</script>";
}
// test mode key
define('STRIPE_SECRET_KEY', 'sk_test_51PHQ8GES6C3ajDZiIowPEAYnXaDpQ7pcvbYyQoJGPVgADHOxOjIaYS45O6Wd3BvTznIGOPBciFcvmmHtxSX725dR00jEd2Q2qD');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51PHQ8GES6C3ajDZig5h8wePCzDzkjJBwhbjJxHhAnctSmOGl9kiwDTdrbT9aMsyvRCasOES9EjedGOK1HeTX3ZzA00oRBIwUoI');

// live mode key
// define('STRIPE_SECRET_KEY', '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');
// define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51PHQ8GES6C3ajDZiBFa0LqYvgK5BZ9YuVvyNqZl4MepvrjYBr3u9C0DeX3VMVA0PV2vYoVYNXgVEidusEgQFwtmG00O1RrCOgk');

?>