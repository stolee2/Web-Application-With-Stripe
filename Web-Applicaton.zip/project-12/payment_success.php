<?php
require_once('header.php');
// session_start();
if (isset($_SESSION['loggeduser'])) {
    $uid = $_SESSION['loggeduser']['id'];
} else {
    rdi('login.php');
}


$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'project-12';
$con = mysqli_connect($host, $user, $pass, $db);
if ($con === false) {
    die('connection_aborted');
}


$sql = "UPDATE`cart` SET status='paid' WHERE userid='$uid'";
$run = $con->query($sql);


$sql_delete = "DELETE FROM `cart` WHERE userid = ? AND status = $run";
$stmt_delete = $con->prepare($sql_delete);
if ($stmt_delete === false) {
    die('Prepare failed: ' . htmlspecialchars($con->error, ENT_QUOTES, 'UTF-8'));
}


$stmt_delete->bind_param('i', $uid);
if ($stmt_delete->execute()) {
    echo "
    <div style='text-align: center; padding: 20px;'>
        <h2 style='color: green;'>Payment Successful!</h2>
        <p>Thank you for your purchase. Your items have been removed from the cart.</p>
    </div>";
} else {
    echo "
    <div style='text-align: center; padding: 20px;'>
        <p style='color: red;'>Error deleting items: " . htmlspecialchars($stmt_delete->error, ENT_QUOTES, 'UTF-8') . "</p>
    </div>";
}
$stmt_delete->close();

$con->close();
require_once('footer.php');
?>



