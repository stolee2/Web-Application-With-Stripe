<?php require_once('header.php'); ?>
      <section class="why_section layout_padding">
         <div class="container">
         
            <div class="row">
               <div class="col-lg-8 offset-lg-2">
                  <div class="common-form">
                     <div class="form-title">
                        <p>Register here</p>
                     </div>
                        <div class="full">
                        <form action="index.php" method="POST">
                           <fieldset>
                              <input type="submit" value="Verify" />
                           </fieldset>
                        </form>
                        </div>
                  </div>   
               </div>
            </div>
         </div>
      </section>
      <!-- end why section -->

<?php //require_once('footer.php'); ?>