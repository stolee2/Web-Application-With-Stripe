<?php
// Assuming $con is the variable representing the database connection

require_once('autoload.php'); // Include the Composer autoload file
require_once('config.php'); // Include your Stripe API keys
require_once('header.php');

if (isset($_SESSION['loggeduser'])) {
    $uid = $_SESSION['loggeduser']['id'];
} else {
    header('Location: login.php');
    exit();
}


require_once './vendor/stripe/stripe-php/init.php';

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

// Calculate total amount from the cart
$sql = "SELECT * FROM `cart` WHERE userid='$uid' AND status='unpaid'";
$run = $con->query($sql);
$total = 0;
while ($data = mysqli_fetch_array($run)) {
    $pid = $data['prodid'];

    $sqlp = "SELECT * FROM `product` WHERE id='$pid'";
    $runp = $con->query($sqlp);
    $datap = mysqli_fetch_array($runp);
    $total += $data['price'];
}

// Create a payment intent
$intent = \Stripe\PaymentIntent::create([
    'amount' => $total * 100, // Stripe accepts amounts in cents
    'currency' => 'usd',
    'payment_method_types' => ['card'],
]);

$clientSecret = $intent->client_secret;
?>
