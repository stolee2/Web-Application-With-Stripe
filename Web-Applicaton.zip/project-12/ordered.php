<?php
require_once('autoload.php'); // Include the autoload file
require_once('config.php'); // Include your Stripe API keys
//require_once('header.php');
// session_start();
if (isset($_SESSION['loggeduser'])) {
$uid = $_SESSION['loggeduser']['id'];
}else{
rdi('login.php');
}

// Calculate total amount from the cart
$sql = "SELECT * FROM `cart` WHERE userid='$uid' AND status='unpaid'";
$run = $con->query($sql);
$total = 0;
while ($data = mysqli_fetch_array($run)) {
    $pid = $data['prodid'];

    $sqlp = "SELECT * FROM `product` WHERE id='$pid'";
    $runp = $con->query($sqlp);
    $datap = mysqli_fetch_array($runp);
    $total += $data['price'];
}


// Create a payment intent
$intent = \Stripe\PaymentIntent::create([
    'amount' => $total * 100, // Stripe accepts amounts in cents
    'currency' => 'usd',
    'payment_method_types' => ['card'],
]);



$clientSecret = $intent->client_secret;
?>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="cart-area">
				<div class="cart-header"><h3>Your order List</h3></div>
				<hr>
				<div class="cart-body-area">

					<div class="single-prod">
						<span class="image">Product image</span>
						<span class="prodtite">Product title</span>
						<span class="prodprice">Price</span>
                        <span class="prodprice">Remove Order</span>
                    </div>
					<hr>

<?php
$sql = "SELECT * FROM `cart` WHERE userid='$uid' AND status ='unpaid'";
$run = $con->query($sql);
$total = 0;
while ($data = mysqli_fetch_array($run)) {
$pid = $data['prodid'];

$sqlp = "SELECT * FROM `product` WHERE id='$pid'";
$runp = $con->query($sqlp);
$datap = mysqli_fetch_array($runp);
$total += $data['price'];
?>
					<div class="single-prod">
						<span class="image"><img height="50px" src="prodimg/<?php echo $datap['img'];?>" alt=""></span>
						<span class="prodtite"><?php echo $datap['title'];?></span>
						<span class="prodprice">$<?php echo $data['price'];?></span>
                        <span class="prodaction"><a href="core/rmv.php?rmvprod=<?php echo $data['id'];?>" class="rmv-btn">Remove</a></span>
                        </div>
					<hr>
<?php } ?>

					<div class="single-prod">
						<span class="image"></span>
						<span class="prodtite"></span>
						<span class="prodprice total">Total $<?php echo $total; ?></span>
                       
                    </div>
                    <br>
                    <br>
                    <div class="">

                    <form id="payment-form">
            <div class="form-group">
                <label for="card-element">Credit or debit card</label>
                <div>
                    <span><div id="card-element"></span>
                </div>
                <div id="card-errors" role="alert"></div>
            </div>
            <button id="submit-button" class="btn btn-primary btn-block">
                Pay $<?php echo $total; ?>
            </button>
        </form>
                    </div>
                </div>                    
            </div>
        </div>
    </div>
</div>  

<br><br>
<?php require_once('footer.php'); ?>

<script src="https://js.stripe.com/v3/"></script>
<script>
    var stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');
    var elements = stripe.elements();
    var card = elements.create('card');
    console.log('stripe 1')
    card.mount('#card-element');

    var form = document.getElementById('payment-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        stripe.confirmCardPayment('<?php echo $clientSecret; ?>', {
            payment_method: {
                card: card,
                billing_details: {
                    // Add any additional billing details here if needed
                }
            }
        }).then(function(result) {
            if (result.error) {
                // Show error to your customer (e.g., insufficient funds)
                document.getElementById('card-errors').textContent = result.error.message;
            } else {
                if (result.paymentIntent.status === 'succeeded') {
                    // The payment has been processed!
                    // You can redirect to a success page or update your order status in the database
                    window.location.href = 'payment_success.php';
                }
            }
        });
    });
</script>
